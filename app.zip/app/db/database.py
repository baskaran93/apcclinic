# import os
# import urllib
# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker, declarative_base
# from dotenv import load_dotenv
#
# load_dotenv()
#
# DB_USERNAME = os.getenv("DB_USERNAME")
# DB_PASSWORD = os.getenv("DB_PASSWORD")
# DB_HOST = os.getenv("DB_HOST")
# DB_PORT = os.getenv("DB_PORT", "1433")
# DB_NAME = os.getenv("DB_NAME")
# DB_DRIVER = os.getenv("DB_DRIVER", "ODBC Driver 17 for SQL Server")
#
# # Build encoded connection string
# connection_string = (
#     f"DRIVER={{{DB_DRIVER}}};"
#     f"SERVER={DB_HOST},{DB_PORT};"
#     f"DATABASE={DB_NAME};"
#     f"UID={DB_USERNAME};"
#     f"PWD={DB_PASSWORD};"
#     "TrustServerCertificate=yes;"
# )
#
# params = urllib.parse.quote_plus(connection_string)
#
# DATABASE_URL = (
#     "mssql+pyodbc://saadmin@insightexpertz:"
#     "YOUR_PASSWORD@insightexpertz.database.windows.net:1433/APCDB"
#     "?driver=ODBC+Driver+18+for+SQL+Server"
#     "&Encrypt=yes"
#     "&TrustServerCertificate=no"
#     "&Connection+Timeout=30"
# )
#
# # Create engine
# engine = create_engine(DATABASE_URL, pool_size=20, max_overflow=0)
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# Base = declarative_base()
#
# # Dependency
# def get_db():
#     db = SessionLocal()
#     try:
#         yield db
#     finally:
#         db.close()

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from urllib.parse import quote_plus

DB_SERVER = "insightexpertz.database.windows.net"
DB_NAME = "APCDB"
DB_USERNAME = "saadmin"
DB_PASSWORD = quote_plus("Insight#123#@!")

DATABASE_URL = (
    f"mssql+pyodbc://{DB_USERNAME}:{DB_PASSWORD}@{DB_SERVER}:1433/{DB_NAME}"
    "?driver=ODBC+Driver+17+for+SQL+Server"
    "&Encrypt=yes"
    "&TrustServerCertificate=no"
    "&Connection+Timeout=30"
)


engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
